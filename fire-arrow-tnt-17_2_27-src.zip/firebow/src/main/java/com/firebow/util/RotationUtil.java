package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * RotationUtil v27 — xoay yaw ngay trước khi di chuyển, không sửa input.
 *
 * arm(): ở tickMovement HEAD, đặt yaw/pitch = góc silent (đã snap lưới chuột).
 *   → travel của tick này tính velocity theo silent yaw, và movement packet cũng mang silent yaw.
 *   → movement client và packet khớp nhau, không cần bù phím, không cần làm tròn.
 * end(): END_CLIENT_TICK, trả yaw/pitch thật.
 *
 * Đánh đổi: trong đúng tick đặt, hướng đi theo phím lệch so với camera một chút.
 * Chỉ dùng trên main thread.
 */
public final class RotationUtil {
    private RotationUtil() {}

    private static boolean active      = false;
    private static float   realYaw     = 0f;
    private static float   realPitch   = 0f;

    public static boolean isActive() { return active; }

    public static void arm(ClientPlayerEntity player, Vec3d hitVec) {
        if (active || player == null) return;
        realYaw   = player.getYaw();
        realPitch = player.getPitch();
        float[] rot = snapToMouseGrid(player, calcRotationFromEye(player.getEyePos(), hitVec));
        applyRaw(player, rot[0], rot[1]);
        active = true;
    }

    /** END_CLIENT_TICK. An toàn khi gọi khi không active hoặc player == null. */
    public static void end(ClientPlayerEntity player) {
        if (active && player != null) applyRaw(player, realYaw, realPitch);
        active = false;
    }

    // ─── Mouse grid (AimModulo360) ───────────────────────────────────────────

    /** Bước góc nhỏ nhất chuột vanilla tạo ra ở sensitivity hiện tại. */
    public static double mouseStep() {
        double sens = MinecraftClient.getInstance().options.getMouseSensitivity().getValue();
        double f = sens * 0.6 + 0.2;
        return f * f * f * 8.0 * 0.15;
    }

    /** Snap góc đích về lưới chuột, delta tính từ góc hiện tại của player. */
    public static float[] snapToMouseGrid(ClientPlayerEntity player, float[] rot) {
        double step   = mouseStep();
        double curYaw = player.getYaw();
        double curPit = player.getPitch();

        double dYaw   = wrap180(rot[0] - curYaw);
        double dPitch = rot[1] - curPit;

        double yaw   = curYaw + Math.round(dYaw   / step) * step;
        double pitch = curPit + Math.round(dPitch / step) * step;

        double maxPitch = Math.floor(90.0 / step) * step;
        pitch = Math.max(-maxPitch, Math.min(maxPitch, pitch));

        return new float[]{ (float) yaw, (float) pitch };
    }

    private static double wrap180(double deg) {
        return ((deg % 360.0) + 540.0) % 360.0 - 180.0;
    }

    // ─── Math ────────────────────────────────────────────────────────────────

    public static float[] calcRotationFromEye(Vec3d eye, Vec3d target) {
        double dx   = target.x - eye.x;
        double dy   = target.y - eye.y;
        double dz   = target.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    /**
     * Điểm hit khi đặt cart lên rail: mặt trên của rail, cao 0.125 so với đáy block.
     * Khớp với BOOST-FPS (placeMinecartOn).
     */
    public static Vec3d railHit(BlockPos rail) {
        return new Vec3d(rail.getX() + 0.5, rail.getY() + 0.125, rail.getZ() + 0.5);
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    private static void applyRaw(ClientPlayerEntity player, float yaw, float pitch) {
        player.setYaw(yaw);
        player.setPitch(pitch);
        player.headYaw = yaw;
        player.bodyYaw = yaw;
    }
}
