package com.firebow.util;

import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Dự đoán điểm mũi tên sẽ đi vào hitbox của TNT minecart đặt trên rail.
 *
 * Khác với bản cũ (PlacementCalc.predictLandingRailPos):
 *  - thứ tự cập nhật giống PersistentProjectileEntity.tick: di chuyển bằng velocity hiện tại,
 *    rồi mới nhân drag 0.99 và trừ gravity 0.05.
 *  - kiểm tra theo sub-step trên đoạn đi, không chỉ tại điểm cuối mỗi tick, để không bỏ sót.
 *  - chỉ coi là trúng khi mũi tên thật sự đi qua hitbox cart (cao 0.7, rộng 0.98, đặt trên rail),
 *    không phải chỉ "bay trên một block solid".
 *  - block có collision shape (tường, cây...) chặn mũi tên trước khi tới cart → trả null.
 *  - entity sống (trừ người bắn) trên đường bay → trả null.
 *
 * Trả về block rail R (air) mà cart sẽ đứng, và số tick tới khi mũi tên chạm cart.
 * Chưa tính va chạm với entity khác (kẻ địch đứng trên đường bay).
 */
public final class ArrowLanding {
    private ArrowLanding() {}

    private static final double GRAVITY     = 0.05;
    private static final double DRAG        = 0.99;
    private static final double CART_BOTTOM = 0.0625;  // đáy hitbox cart trên rail
    private static final double CART_TOP    = 0.7625;  // đỉnh hitbox cart (cao 0.7)
    private static final double CART_HALF   = 0.49;    // nửa chiều rộng hitbox (0.98)

    /** Bật: mũi tên bị entity sống chặn trên đường bay thì không dự đoán. Tắt mặc định để tránh bỏ oan. */
    public static boolean BLOCK_BY_ENTITIES = false;

    public record Hit(BlockPos cartBlock, int ticks) {}

    public static Hit predict(World world, Vec3d pos, Vec3d vel, int maxTicks) {
        return predict(world, pos, vel, maxTicks, null);
    }

    /**
     * @param shooter entity bắn (bỏ qua khi kiểm tra va chạm entity), có thể null.
     */
    public static Hit predict(World world, Vec3d pos, Vec3d vel, int maxTicks, Entity shooter) {
        Vec3d p = pos;
        Vec3d v = vel;

        for (int t = 0; t < maxTicks; t++) {
            Vec3d next = p.add(v);

            int steps = Math.max(2, (int) Math.ceil(v.length() / 0.2));
            for (int s = 1; s <= steps; s++) {
                double f = (double) s / steps;
                double x = p.x + (next.x - p.x) * f;
                double y = p.y + (next.y - p.y) * f;
                double z = p.z + (next.z - p.z) * f;

                BlockPos b = BlockPos.ofFloored(x, y, z);
                BlockState st = world.getBlockState(b);

                // entity sống trên đường bay sẽ nhận mũi tên trước cart (chỉ khi bật cờ)
                if (BLOCK_BY_ENTITIES) {
                    Box hb = new Box(x - 0.25, y - 0.25, z - 0.25, x + 0.25, y + 0.25, z + 0.25);
                    if (!world.getOtherEntities(shooter, hb, e -> e instanceof LivingEntity && e.isAlive()).isEmpty()) {
                        return null;
                    }
                }

                // candidate: block không khí, đáy là nền solid, mũi tên đi qua đáy-đỉnh hitbox cart
                if (st.isAir()) {
                    double dy = y - b.getY();
                    double cx = b.getX() + 0.5;
                    double cz = b.getZ() + 0.5;
                    boolean inBand  = dy >= CART_BOTTOM && dy <= CART_TOP;
                    boolean inWidth = Math.abs(x - cx) <= CART_HALF && Math.abs(z - cz) <= CART_HALF;
                    if (inBand && inWidth && PlacementCalc.isSolidGround(world, b.down())) {
                        return new Hit(b, t);
                    }
                    continue;
                }

                // block có collision (tường, nền...) chặn mũi tên trước khi tới cart
                if (!st.getCollisionShape(world, b).isEmpty()) return null;
            }

            p = next;
            v = new Vec3d(v.x * DRAG, v.y * DRAG - GRAVITY, v.z * DRAG);
        }
        return null;
    }
}
